<!DOCTYPE html>
<html>
<body>

<?php
$file = fopen("test.txt","r");
fclose($file);
?>

</body>
</html>