<!DOCTYPE html>
<html>
<body>

<?php
echo file_exists("test.txt");
?>

</body>
</html>