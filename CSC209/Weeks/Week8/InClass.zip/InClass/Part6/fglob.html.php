<!DOCTYPE html>
<html>
<body>

<?php
print_r(glob("*.txt"));
?>

<body>
<html>